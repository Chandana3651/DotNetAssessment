﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using CustomerManagement;


namespace CustomerSerialization
{
    [Serializable]
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }

        public override string ToString()
        {
            return string.Format($"The ID: {Id}\nThe name: {Name} \nTjhe Address: {Address}");
        }
    }
    class Serialization
    {
        static void Main(string[] args)
        {
            binaryExample();
            Console.ReadKey();
        }

        private static void binaryExample()
        {
            Console.WriteLine("What do U want to do today: Read or Write");
            string choice = Console.ReadLine();
            if (choice.ToLower() == "read")
                deserializing();
            else
                serializing();
        }

        private static void deserializing()
        {
            FileStream fs = new FileStream("Demo.bin", FileMode.Open, FileAccess.Read);
            BinaryFormatter fm = new BinaryFormatter();
            Customer c = fm.Deserialize(fs) as Customer;
            Console.WriteLine(c.Name);
            fs.Close();
        }

        private static void serializing()
        {
            Customer c = new Customer();
            c.Id = MyConsole.getNumber("Enter the ID");
            c.Name = MyConsole.getString("Enter the name");
            c.Address = MyConsole.getString("Enter the address");
            BinaryFormatter fm = new BinaryFormatter();
            FileStream fs = new FileStream("Demo.bin", FileMode.OpenOrCreate, FileAccess.Write);
            fm.Serialize(fs, c);
            fs.Close();
        }
    }
}