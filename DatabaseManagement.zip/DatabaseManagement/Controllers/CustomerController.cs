﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DatabaseManagement.Models;

namespace DatabaseManagement.Controllers
{
    public class CustomerController : Controller
    {
        public ViewResult AllCustomer()
        {
            var data = new DataBaseEntities();
            var model = data.MyTables.ToList();
            return View(model);
        }

        public ViewResult Find(string id)
        {
            int Id = int.Parse(id);
            var data = new DataBaseEntities();
            var model = data.MyTables.FirstOrDefault((c) => c.Id == Id);
            return View(model);
        }

        [HttpPost]
        public ActionResult Find(MyTable cust)
        {
            var data = new DataBaseEntities();
            var model = data.MyTables.FirstOrDefault((c) => c.Id == cust.Id);
            model.Name = cust.Name;
            model.Address = cust.Address;
            data.SaveChanges();
            return RedirectToAction("AllCustomer");
        }
        public ViewResult NewCustomer()
        {
            var model = new MyTable();
            return View(model);
        }

        [HttpPost]
        public ActionResult NewCustomer(MyTable cust)
        {
            var data= new DataBaseEntities();
            data.MyTables.Add(cust);
            data.SaveChanges();
            return RedirectToAction("AllCustomer");
        }

        public ActionResult Delete(string id)
        {
            //convert string to int
            int Id = int.Parse(id);
            var data = new DataBaseEntities();
            var model = data.MyTables.FirstOrDefault((e) => e.Id == Id);
            data.MyTables.Remove(model);
            data.SaveChanges();
            return RedirectToAction("AllCustomer");
        }
    }
}
